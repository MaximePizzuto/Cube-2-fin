# Cube-2-Projet-Raspberry

Utiliser la commande "node server" pour générer le serveur. Celui-ci s'ouvrira sur le port 3080. Insérer le lien suivant dans la barre de recherche : http://localhost:3080/ 

