export const environment = {
    settings: {
        apiUrl: 'http://localhost:5283/api/Meteo'
    }
};