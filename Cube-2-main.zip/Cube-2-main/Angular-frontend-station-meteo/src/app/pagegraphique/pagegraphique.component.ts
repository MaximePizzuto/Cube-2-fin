import { Component } from '@angular/core';

@Component({
  selector: 'app-pagegraphique',
  templateUrl: './pagegraphique.component.html',
  styleUrls: ['./pagegraphique.component.css']
})
export class PagegraphiqueComponent {

}
