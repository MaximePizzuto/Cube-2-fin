export interface Sonde {
    id: number;
    mac: number;
    createat: number;
    lastconnected: number;
}