export interface Meteo {
    id: number;
    temperature: number;
    pression: number;
    humidite: number;
    createAt: Date;
    sondeId: number;
}