import { Component } from '@angular/core';

@Component({
  selector: 'app-lienpageaccueil',
  templateUrl: './lienpageaccueil.component.html',
  styleUrls: ['./lienpageaccueil.component.css']
})
export class LienpageaccueilComponent {

}
